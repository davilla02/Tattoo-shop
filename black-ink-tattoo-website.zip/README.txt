BLACK INK TATTOO STUDIO WEBSITE

1. Open index.html to preview the site.
2. Replace the studio name, text, phone/WhatsApp number, address and demo gallery panels.
3. Upload index.html to GitHub Pages or Cloudflare Pages for free hosting.

FREE HOSTING:
- GitHub Pages: https://pages.github.com/
- Cloudflare Pages: https://pages.cloudflare.com/

IMPORTANT:
A truly free custom domain such as yourstudio.com is generally not included. Free hosting can give you a free address such as username.github.io or yourproject.pages.dev. A custom .com/.net/.studio domain normally needs to be registered separately.
